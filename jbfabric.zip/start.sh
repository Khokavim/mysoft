#!/bin/bash

export FABRIC_VERSION=hlfv11
./config/hlfv11/downloadFabric.sh

sleep 8
rm -rf node_modules
npm i -g composer-cli@0.20 composer-rest-server@0.20 generator-hyperledger-composer@0.20
npm i
npm run prepublish
npm run config:start
npm run config:peerAdmin


echo "See docker images"
docker ps

sleep 10

echo "setup admin"
# composer network install --card PeerAdmin@hlfv1 --archiveFile ./dist/jbfabric.bna
# composer network start --networkName jbfabric --networkVersion 0.0.3 --networkAdmin admin --networkAdminEnrollSecret adminpw --card PeerAdmin@hlfv1 --file networkadmin.card
composer card import --file ./networkadmin.card

echo "Ping network if we are live"
composer network ping --card admin@jbfabric

echo "Start server at :3000"
composer-rest-server -c admin@jbfabric -n never -u true -d JBFABRIC -w true